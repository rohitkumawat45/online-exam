package project.onlineexam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegistrationCont {
	
	@Autowired
	SessionFactory fact;
	
	@RequestMapping("save")
	public ModelAndView save(Users user)
	{
		Session ss = fact.openSession();
		
		Transaction tx = ss.beginTransaction();
		ss.save(user);
		tx.commit();
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("message","Registration Succesfull");
		mv.setViewName("login");
		
		return mv;
	}
}
