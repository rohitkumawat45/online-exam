package project.onlineexam;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@Autowired
	SessionFactory sf;
	
	@RequestMapping("login")
	public String login () 
	{	
		return "login";	
	}
	
	@RequestMapping("showregister")
	public String showregister() 
	{
		return "register";
	}
	
	@RequestMapping("validate")
	public ModelAndView validate(String username ,String password) 
	{
		ModelAndView mv = new ModelAndView();
		Session ss = sf.openSession();
		Users users =null;
		
		if(!username.equals("admin"))
		{
			users =ss.load(Users.class, username);
		}
		
		if(username.equals("admin") && password.equals("admin"))
		{
			mv.setViewName("admincontroller");
			mv.addObject("message", "Welcome Admin");
		}
		
		else if(username.equals(users.getUsername()) && password.equals(users.getPassword()))
		{
			mv.setViewName("welcome");
			mv.addObject("message", "welcome " + username);
		}
		else
		{
			mv.setViewName("login");
			mv.addObject("message" , "invalid details");
		}
		return mv;
	}
	
	@RequestMapping("startexam")
	public ModelAndView startexam(String selectedsubject ,HttpServletRequest request)
	{	
		HttpSession httpsession = request.getSession();
		httpsession.setAttribute("qno",0);
		Session ss = sf.openSession();
		List<Questions> qlist = ss.createCriteria(Questions.class).add(Restrictions.eq("subject" ,selectedsubject)).list();
		ModelAndView mv = new ModelAndView();
		
		httpsession.setAttribute("allquestions", qlist);
		mv.setViewName("questions");
		mv.addObject("que" ,qlist.get(0));
		
		HashMap<String, Answer> hashmap = new HashMap<String, Answer>();
		httpsession.setAttribute("submitteddetails", hashmap);
		httpsession.setAttribute("score", 0);
		
		httpsession.setAttribute("timeremaining", 301);
		
		return mv;
	}
}
