package project.onlineexam;

public class Answer {

	String qno;
	String question;
	String originalAnswer;
	String submittedAnswer;

	@Override
	public String toString() {
		return "Answer [qno=" + qno + ", question=" + question + ", originalAnswer=" + originalAnswer
				+ ", submittedAnswer=" + submittedAnswer + "]";
	}

	public String getQno() {
		return qno;
	}

	public void setQno(String qno) {
		this.qno = qno;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getOriginalAnswer() {
		return originalAnswer;
	}

	public void setOriginalAnswer(String originalAnswer) {
		this.originalAnswer = originalAnswer;
	}

	public String getSubmittedAnswer() {
		return submittedAnswer;
	}

	public void setSubmittedAnswer(String submittedAnswer) {
		this.submittedAnswer = submittedAnswer;
	}

}
