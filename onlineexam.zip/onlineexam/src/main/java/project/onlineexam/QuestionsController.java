package project.onlineexam;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class QuestionsController {

	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		HttpSession httpsession = request.getSession();
		Integer i = (Integer) httpsession.getAttribute("qno");
		int nextqno = i+1;
		
		List<Questions> list = (List<Questions>)httpsession.getAttribute("allquestions");
		mv.setViewName("questions");
		
		if(nextqno<list.size()) {
		
			Questions q = list.get(nextqno);
			mv.addObject("que",q);
			httpsession.setAttribute("qno", nextqno);
		}
		else
		{
			mv.addObject("que", list.get(list.size()-1));
			mv.addObject("complete", "Questions Completed");
		}
		return mv;
	}
	
	@RequestMapping("previous")
	public ModelAndView previous(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		HttpSession httpsession = request.getSession();
		
		Integer i = (Integer) httpsession.getAttribute("qno");
		int previousqno = i-1;
		
		List<Questions> list = (List<Questions>) httpsession.getAttribute("allquestions");
		mv.setViewName("questions");
		
		if(previousqno>=0)
		{
			Questions q = list.get(previousqno);
			mv.addObject("que", q);
			httpsession.setAttribute("qno", previousqno);
		}
		else
		{
			mv.addObject("que" ,list.get(0));    
			mv.addObject("message", "Click on next");
		}
		return mv;
	}
	
	@RequestMapping("saveResponse")
	public void saveResponse(Answer answer, HttpServletRequest request)
	{
		HttpSession httpsession = request.getSession();
		List<Questions> list = (List<Questions>) httpsession.getAttribute("allquestions");
		
		for (Questions questions : list) {
			if(questions.qno.equals(answer.qno)) 
			{
				String ans = questions.answer;
				answer.setOriginalAnswer(ans);
				break;
			}
		}
		HashMap<String, Answer> hashmap = (HashMap<String, Answer>) httpsession.getAttribute("submitteddetails");
		hashmap.put(answer.qno, answer);
		
		System.out.println(hashmap);
	}
	
	@RequestMapping("endexam")
	public ModelAndView endexam(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		HttpSession httpsession = request.getSession();
		
		HashMap<String, Answer> hashmap = (HashMap<String, Answer>) httpsession.getAttribute("submitteddetails");
		Collection<Answer> allans= hashmap.values();
		
		for (Answer answer : allans) 
		{
			if(answer.originalAnswer.equals(answer.submittedAnswer))
					{
				httpsession.setAttribute("score",(Integer) httpsession.getAttribute("score")+1);
					}
		}
		mv.setViewName("score");
		mv.addObject("finalscore", httpsession.getAttribute("score"));
		mv.addObject("allans",allans);
		httpsession.invalidate();
		
		return mv;
	}
}
