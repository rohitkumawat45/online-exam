package project.onlineexam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {

	@Autowired
	SessionFactory factory;
	
	@RequestMapping("addQuestion")
	public ModelAndView addQuestion(Questions question)
	{
		
		ModelAndView mv = new ModelAndView();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(question);
		
		tx.commit();
		
		mv.setViewName("adminController");
		mv.addObject("message", "Question Added Sucessfully");
		
		return mv;
	}
	
	@RequestMapping("updateQuestion")
	public ModelAndView updateQuestion(Questions question)
	{
		
		ModelAndView mv = new ModelAndView();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(question);
		
		tx.commit();
		
		mv.setViewName("adminController");
		mv.addObject("message", "Question Updated Sucessfully");
		
		return mv;
	}
	
	@RequestMapping("deleteQuestion")
	public ModelAndView deleteQuestion(Questions question)
	{
		
		ModelAndView mv = new ModelAndView();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(question);
		
		tx.commit();
		
		mv.setViewName("adminController");
		mv.addObject("message", "Question Deleted Sucessfully");
		
		return mv;
	}
}
